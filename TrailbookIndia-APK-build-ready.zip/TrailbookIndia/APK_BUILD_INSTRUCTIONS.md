# Trailbook India — APK build

This project is configured to build a debug APK using GitHub Actions.

## Build using a phone

1. Extract this ZIP.
2. Create a GitHub repository and upload the *contents* of the `TrailbookIndia` folder (the folder contents, not an extra nested folder).
3. In the repository, open **Actions**.
4. Select **Build Android APK**.
5. Tap **Run workflow** (or push to the `main` branch).
6. When the workflow finishes, open its run, scroll to **Artifacts**, and download `TrailbookIndia-debug-apk`.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Local HTML

The app loads `app/src/main/assets/index.html`. Keep this file in that exact location.
